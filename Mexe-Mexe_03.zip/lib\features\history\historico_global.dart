import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:mindful_you/services/database_service.dart';

export 'package:mindful_you/features/checkin/domain/historico_calculos.dart';

// ============================================================
// HISTÓRICO DE CHECK-INS DO USUÁRIO LOGADO
// ============================================================
//
// BUG CORRIGIDO: antes, todo o histórico de check-ins (e os campos
// "último sentimento/emoji/data") ficavam salvos em chaves globais do
// SharedPreferences — as mesmas para qualquer conta usada no aparelho.
// Como o app permite múltiplas contas (login/cadastro/gerenciar
// usuários), trocar de usuário (logout + login com outra conta) fazia
// a pessoa ver o histórico de check-ins de quem tivesse usado o app
// antes dela no mesmo celular.
//
// Agora cada check-in é salvo na tabela `checkins` do SQLite
// (`database_service.dart`), vinculado ao `usuario_id` de quem
// respondeu. Esta lista em memória continua existindo (para não
// precisar mudar todas as telas que já a usam), mas passa a ser
// apenas um cache dos registros do usuário atualmente logado.

/// Lista em memória — cache dos check-ins do usuário atualmente logado.
List<Map<String, dynamic>> historicoGlobal = [];

// Invalida resultados de carregamentos anteriores que terminem fora de ordem.
int _versaoCarregamentoHistorico = 0;

/// Retorna o id do usuário atualmente logado (salvo em SharedPreferences
/// no login/cadastro), ou `null` se não houver ninguém logado.
Future<int?> _usuarioIdAtual() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getInt('usuarioId');
}

/// Converte uma linha da tabela `checkins` para o mesmo formato de Map
/// que as telas (Histórico, Gráfico, Relatório etc) já esperavam
/// quando o histórico vinha do SharedPreferences.
Map<String, dynamic> _linhaParaEntrada(Map<String, dynamic> linha) {
  final cansaco = linha['cansaco'] as num?;
  final ansiedade = linha['ansiedade'] as num?;
  final sono = linha['sono'] as num?;
  final produtividade = linha['produtividade'] as num?;

  final atividade = linha['atividade_significativa']?.toString();
  final sentimento = linha['sentimento']?.toString() ?? '';
  final emoji = linha['emoji']?.toString() ?? '';

  // Sinais de humor e energia (podem vir vazios em check-ins salvos
  // antes desta funcionalidade existir).
  final humorFrequencia = linha['humor_frequencia']?.toString() ?? '';
  final interesseFrequencia = linha['interesse_frequencia']?.toString() ?? '';
  final exaustaoBurnout = linha['exaustao_burnout']?.toString() ?? '';
  final distanciamentoBurnout =
      linha['distanciamento_burnout']?.toString() ?? '';

  return {
    'data': linha['data_formatada'],
    'dataIso': linha['data_iso'],
    'sentimento': sentimento,
    'emoji': emoji,
    // BUG CORRIGIDO: os cards de `historico_tela.dart` (último check-in
    // e cada item da lista) leem `item['status']` para mostrar um
    // resumo do registro, mas essa chave nunca era preenchida — todo
    // check-in aparecia com o texto genérico "Check-in realizado".
    // Agora usamos o sentimento e o emoji escolhidos no questionário.
    'status': sentimento.isNotEmpty
        ? '$sentimento ${emoji.isNotEmpty ? emoji : ''}'.trim()
        : null,
    'cor': linha['cor_valor'] is int
        ? Color(linha['cor_valor'] as int)
        : const Color(0xFFE8DCD4),
    'bemEstar': linha['bem_estar'],
    'atividadeSignificativa': atividade,
    'dadosGrafico': {
      'cansaco': cansaco,
      'ansiedade': ansiedade,
      'sono': sono,
      'produtividade': produtividade,
      'atividadeSignificativa': atividade,
    },
    // Sinais de humor e energia — ver observação no topo da seção
    // "SINAIS DE HUMOR E ENERGIA" mais abaixo neste arquivo.
    'humorFrequencia': humorFrequencia,
    'interesseFrequencia': interesseFrequencia,
    'exaustaoBurnout': exaustaoBurnout,
    'distanciamentoBurnout': distanciamentoBurnout,
    // Mantém compatibilidade com a tela de Relatório (RegistrosTela),
    // que espera 'perguntas' e 'respostas'. Os 4 itens de humor e
    // energia só entram na lista quando o check-in tem alguma
    // resposta salva para eles (check-ins antigos, de antes desta
    // funcionalidade, não têm — e não devem aparecer como "vazio"
    // no relatório).
    'perguntas': [
      'Cansaço',
      'Ansiedade',
      'Falta de sono',
      if (atividade == null) 'Produtividade' else 'Atividade significativa',
      if (humorFrequencia.isNotEmpty) 'Humor (desânimo ou tristeza)',
      if (interesseFrequencia.isNotEmpty) 'Interesse ou prazer',
      if (exaustaoBurnout.isNotEmpty) 'Exaustão emocional',
      if (distanciamentoBurnout.isNotEmpty) 'Distanciamento ou desmotivação',
    ],
    'respostas': [
      (cansaco == null ? 'Não informado' : '${cansaco.toInt()}%'),
      (ansiedade == null ? 'Não informado' : '${ansiedade.toInt()}%'),
      (sono == null ? 'Não informado' : '${sono.toInt()}%'),
      if (atividade == null)
        (produtividade == null ? 'Não informado' : '${produtividade.toInt()}%')
      else if (atividade == 'Prefiro não responder')
        'Não informado'
      else
        atividade,
      if (humorFrequencia.isNotEmpty) humorFrequencia,
      if (interesseFrequencia.isNotEmpty) interesseFrequencia,
      if (exaustaoBurnout.isNotEmpty) exaustaoBurnout,
      if (distanciamentoBurnout.isNotEmpty) distanciamentoBurnout,
    ],
    'principalPonto': linha['principal_ponto'],
  };
}

/// Carrega, da tabela `checkins` do SQLite para a lista em memória, os
/// registros do usuário atualmente logado (do mais antigo para o mais
/// recente). Deve ser chamado sempre que um usuário faz login ou
/// cadastro — assim a lista em memória nunca mistura o histórico de
/// outra conta que tenha usado o app no mesmo aparelho.
Future<void> carregarHistorico() async {
  final versao = ++_versaoCarregamentoHistorico;
  final usuarioId = await _usuarioIdAtual();
  if (versao != _versaoCarregamentoHistorico) return;

  if (usuarioId == null) {
    historicoGlobal = [];
    return;
  }

  final linhas = await DatabaseService.instance.listarCheckins(usuarioId);
  if (versao != _versaoCarregamentoHistorico) return;
  // A conta pode ter mudado enquanto o SQLite respondia.
  if (await _usuarioIdAtual() != usuarioId) {
    historicoGlobal = [];
    return;
  }
  if (versao != _versaoCarregamentoHistorico) return;
  historicoGlobal = linhas.map(_linhaParaEntrada).toList();
}

/// Adiciona um check-in ao histórico do usuário atualmente logado,
/// persistindo na tabela `checkins` do SQLite, e atualiza a lista em
/// memória. Se não houver usuário logado (não deveria acontecer, já
/// que só se chega ao questionário depois do login), o check-in não é
/// salvo.
Future<void> adicionarHistorico(Map<String, dynamic> entrada) async {
  final usuarioId = await _usuarioIdAtual();
  if (usuarioId == null) return;

  final dadosGrafico = entrada['dadosGrafico'] as Map? ?? {};
  final cor = entrada['cor'];

  await DatabaseService.instance.inserirCheckin(
    usuarioId: usuarioId,
    dataIso: entrada['dataIso']?.toString() ?? DateTime.now().toIso8601String(),
    dataFormatada: entrada['data']?.toString() ?? '',
    sentimento: entrada['sentimento']?.toString() ?? '',
    emoji: entrada['emoji']?.toString() ?? '🙂',
    cansaco: (dadosGrafico['cansaco'] as num?)?.toDouble() ?? 0,
    ansiedade: (dadosGrafico['ansiedade'] as num?)?.toDouble() ?? 0,
    sono: (dadosGrafico['sono'] as num?)?.toDouble() ?? 0,
    produtividade: (dadosGrafico['produtividade'] as num?)?.toDouble(),
    atividadeSignificativa: entrada['atividadeSignificativa']?.toString(),
    bemEstar: (entrada['bemEstar'] as num).round(),
    principalPonto: entrada['principalPonto']?.toString() ?? '',
    corValor: cor is Color ? cor.toARGB32() : 0xFFE8DCD4,
    humorFrequencia: entrada['humorFrequencia']?.toString() ?? '',
    interesseFrequencia: entrada['interesseFrequencia']?.toString() ?? '',
    exaustaoBurnout: entrada['exaustaoBurnout']?.toString() ?? '',
    distanciamentoBurnout: entrada['distanciamentoBurnout']?.toString() ?? '',
    operacaoId: entrada['operacaoId'] as String?,
  );

  // Recarrega a lista em memória para refletir o novo registro.
  await carregarHistorico();
}

/// Limpa todo o histórico salvo (memória + SQLite) do usuário
/// atualmente logado.
Future<void> limparHistorico() async {
  final usuarioId = await _usuarioIdAtual();
  if (usuarioId != null) {
    await DatabaseService.instance.limparCheckins(usuarioId);
  }
  // Não apagar o cache de uma conta que entrou durante a operação.
  if (await _usuarioIdAtual() == usuarioId) {
    ++_versaoCarregamentoHistorico;
    historicoGlobal = [];
  }
}
