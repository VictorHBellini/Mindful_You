import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:mindful_you/features/auth/screens/account_link_preflight_screen.dart';
import 'package:mindful_you/features/auth/firebase_teste_tela.dart';
import 'package:mindful_you/core/theme/mindful_cores.dart';
import 'package:mindful_you/features/settings/vincular_firebase_demo_tela.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:mindful_you/features/history/historico_global.dart';
import 'package:mindful_you/services/database_service.dart';
import 'package:mindful_you/features/profile/services/foto_perfil_service.dart';
import 'package:mindful_you/services/theme_service.dart';
import 'package:mindful_you/widgets/avatar_perfil.dart';

class ConfiguracaoTela extends StatefulWidget {
  const ConfiguracaoTela({super.key});

  @override
  State<ConfiguracaoTela> createState() => _ConfiguracaoTelaState();
}

class _ConfiguracaoTelaState extends State<ConfiguracaoTela> {
  bool notificacao = false;
  bool temaEscuro = false;

  String nomeUsuario = "Usuário";
  String emailUsuario = "";

  @override
  void initState() {
    super.initState();
    carregarDados();
  }

  Future<void> carregarDados() async {
    final prefs = await SharedPreferences.getInstance();

    if (!mounted) return;

    setState(() {
      nomeUsuario = prefs.getString('nomeUsuario') ?? "Usuário";
      emailUsuario = prefs.getString('emailUsuario') ?? "";
      notificacao = prefs.getBool('notificacao') ?? false;
      temaEscuro = prefs.getBool('temaEscuro') ?? false;
    });
  }

  Future<void> salvarPreferencias() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setBool(
      'notificacao',
      notificacao,
    );

    await prefs.setBool(
      'temaEscuro',
      temaEscuro,
    );
  }

  Future<void> _excluirDadosLocais() async {
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir dados locais?'),
        content: const Text(
          'Seu perfil e histórico salvos neste dispositivo serão removidos. Esta ação não pode ser desfeita.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(
              foregroundColor: Colors.red,
            ),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirmar != true) return;

    final prefs = await SharedPreferences.getInstance();

    // Exclui o usuário do banco SQLite pelo e-mail salvo
    final email = prefs.getString('emailUsuario');
    if (email != null && email.isNotEmpty) {
      final usuario = await DatabaseService.instance.buscarPorEmail(email);
      if (usuario != null) {
        await DatabaseService.instance.deletarUsuario(usuario['id'] as int);
        await FotoPerfilService.removerFotoAntiga(
          usuario['foto_path'] as String?,
        );
      }
    }

    await limparHistorico();

    // BUG CORRIGIDO: antes só removíamos 3 chaves (nomeUsuario,
    // emailUsuario, ultimoQuestionario), deixando pra trás outros
    // dados reais do usuário salvos no aparelho — foto de perfil,
    // último check-in, contadores de humor, preferências de tema e
    // notificação. Se outra pessoa criasse uma conta nova no mesmo
    // aparelho depois, esses dados antigos apareciam na conta nova.
    // Agora limpamos tudo de uma vez.
    await prefs.clear();

    if (!mounted) return;

    Navigator.pushNamedAndRemoveUntil(
      context,
      '/login',
      (_) => false,
    );
  }

  Widget _sectionCard({
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: Theme.of(context).dividerColor,
        ),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.black.withValues(alpha: 0.18)
                : Colors.black.withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: Icon(
                    Icons.arrow_back_ios_new_rounded,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Container(
                width: 106,
                height: 106,
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.05),
                      blurRadius: 15,
                    ),
                  ],
                ),
                child: const AvatarPerfil(radius: 50),
              ),
              const SizedBox(height: 18),
              Text(
                nomeUsuario,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                emailUsuario.isEmpty
                    ? "Nenhum e-mail cadastrado"
                    : emailUsuario,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  fontSize: 15,
                ),
              ),
              const SizedBox(height: 30),
              _sectionCard(
                child: Column(
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.person_outline_rounded,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        SizedBox(width: 10),
                        Text(
                          "Minha Conta",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          Navigator.pushNamed(
                            context,
                            '/perfil',
                          );
                        },
                        icon: const Icon(
                          Icons.edit_outlined,
                        ),
                        label: const Text(
                          "Editar Perfil",
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor:
                              Theme.of(context).brightness == Brightness.dark
                                  ? MindfulCores.rosaPrimarioEscuro
                                  : const Color(0xFF8D6E63),
                          foregroundColor:
                              Theme.of(context).brightness == Brightness.dark
                                  ? MindfulCores.contrasteRosaEscuro
                                  : Colors.white,
                          minimumSize: const Size(double.infinity, 52),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              _sectionCard(
                child: Column(
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.tune_rounded,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        SizedBox(width: 10),
                        Text(
                          "Preferências",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text(
                        "Notificações",
                      ),
                      secondary: const Icon(
                        Icons.notifications_none_rounded,
                      ),
                      value: notificacao,
                      onChanged: (value) {
                        setState(() {
                          notificacao = value;
                        });

                        salvarPreferencias();
                      },
                    ),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text(
                        "Tema escuro",
                      ),
                      secondary: const Icon(
                        Icons.dark_mode_outlined,
                      ),
                      value: temaEscuro,
                      onChanged: (value) {
                        setState(() {
                          temaEscuro = value;
                        });

                        ThemeService.setDark(value);
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              if (kDebugMode && !kIsWeb)
                _sectionCard(
                    child: ListTile(
                  leading: const Icon(Icons.verified_user_outlined),
                  title: const Text('Pré-verificação Firebase (laboratório)'),
                  subtitle: const Text('Somente testes; sem criar vínculos'),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                        builder: (_) => const AccountLinkPreflightScreen(),
                      )),
                )),
              if (kDebugMode && !kIsWeb) const SizedBox(height: 18),
              if (kDebugMode && !kIsWeb)
                _sectionCard(
                  child: ListTile(
                    leading: const Icon(Icons.science_outlined),
                    title: const Text('Laboratório Firebase F2.3'),
                    subtitle: const Text('Entrar na conta Firebase de teste'),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                        builder: (_) => const FirebaseTesteTela(),
                      ),
                    ),
                  ),
                ),
              if (kDebugMode && !kIsWeb) const SizedBox(height: 18),
              if (const bool.fromEnvironment('MINDFUL_FIREBASE_EMULATORS',
                  defaultValue: false))
                _sectionCard(
                    child: ListTile(
                  leading: const Icon(Icons.link),
                  title: const Text('Vincular Firebase (demonstração)'),
                  subtitle:
                      const Text('Solicitação pendente; sem sincronização'),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                        builder: (_) => const VincularFirebaseDemoTela(),
                      )),
                )),
              const SizedBox(height: 18),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.red.withValues(alpha: 0.05),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.red.withValues(alpha: 0.20),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(
                          Icons.warning_amber_rounded,
                          color: Colors.red,
                        ),
                        SizedBox(width: 8),
                        Text(
                          "Zona Sensível",
                          style: TextStyle(
                            color: Colors.red,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    TextButton.icon(
                      onPressed: _excluirDadosLocais,
                      icon: const Icon(
                        Icons.delete_outline_rounded,
                        color: Colors.red,
                      ),
                      label: const Text(
                        "Excluir conta permanentemente",
                        style: TextStyle(
                          color: Colors.red,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}
