import 'account_link_policy.dart';
import 'auth_contracts.dart';

/// Prova local recente deve vir de uma nova validação da senha SQLite.
/// Não aceite apenas uma sessão persistida como prova de posse.
abstract class RecentLocalAccountProof {
  Future<bool> verifyLocalUser(int localUserId);
}

/// Identidade remota deve ser obtida de uma autenticação Firebase recente.
/// Não confie em e-mail digitado ou em um UID fornecido pela interface.
abstract class FreshRemoteAccountProof {
  Future<AuthIdentity?> authenticateAgain();
}

/// Consulta os vínculos atuais; a implementação deve usar o banco local.
abstract class AccountLinkConflictLookup {
  Future<String?> linkedUidForLocalUser(int localUserId);
  Future<bool> uidBelongsToOtherUser(String uid, int localUserId);
}

/// Apenas pré-verificação: NÃO grava, NÃO cria sessão e NÃO autoriza sync.
/// O backend ainda deve comprovar as duas identidades antes de vincular.
class AccountLinkPreflight {
  const AccountLinkPreflight({
    required this.localProof,
    required this.remoteProof,
    required this.conflicts,
  });

  final RecentLocalAccountProof localProof;
  final FreshRemoteAccountProof remoteProof;
  final AccountLinkConflictLookup conflicts;

  Future<AccountLinkDecision> check(int localUserId) async {
    if (localUserId <= 0) {
      return AccountLinkDecision.localAuthenticationRequired;
    }
    if (!await localProof.verifyLocalUser(localUserId)) {
      return AccountLinkDecision.localAuthenticationRequired;
    }
    final identity = await remoteProof.authenticateAgain();
    if (identity == null ||
        identity.provider != AuthProviderKind.firebase ||
        identity.providerUserId.trim().isEmpty) {
      return AccountLinkDecision.remoteAuthenticationRequired;
    }
    if (!identity.emailVerified) {
      return AccountLinkDecision.verifiedEmailRequired;
    }
    final existing = await conflicts.linkedUidForLocalUser(localUserId);
    final other = await conflicts.uidBelongsToOtherUser(
      identity.providerUserId,
      localUserId,
    );
    return const AccountLinkPolicy().evaluate(
      authenticatedLocalUserId: localUserId,
      remoteIdentity: identity,
      alreadyLinkedUidForLocalUser: existing,
      remoteUidLinkedToAnotherLocalUser: other,
    );
  }
}
