import 'auth_contracts.dart';

/// Validação preliminar para um futuro vínculo SQLite <-> Firebase.
/// NÃO cria vínculos, não concede sessão local e não migra dados.
/// A implementação persistente deverá validar novamente os IDs e a
/// unicidade dentro de uma transação no banco de dados.
enum AccountLinkDecision {
  eligibleForServerVerification,
  localAuthenticationRequired,
  remoteAuthenticationRequired,
  verifiedEmailRequired,
  conflictingRemoteIdentity,
  remoteIdentityAlreadyLinked,
}

class AccountLinkPolicy {
  const AccountLinkPolicy();

  AccountLinkDecision evaluate({
    required int? authenticatedLocalUserId,
    required AuthIdentity? remoteIdentity,
    required String? alreadyLinkedUidForLocalUser,
    required bool remoteUidLinkedToAnotherLocalUser,
  }) {
    if (authenticatedLocalUserId == null || authenticatedLocalUserId <= 0) {
      return AccountLinkDecision.localAuthenticationRequired;
    }
    if (remoteIdentity == null ||
        remoteIdentity.provider != AuthProviderKind.firebase ||
        remoteIdentity.providerUserId.trim().isEmpty) {
      return AccountLinkDecision.remoteAuthenticationRequired;
    }
    if (!remoteIdentity.emailVerified) {
      return AccountLinkDecision.verifiedEmailRequired;
    }
    if (remoteUidLinkedToAnotherLocalUser) {
      return AccountLinkDecision.remoteIdentityAlreadyLinked;
    }
    final existing = alreadyLinkedUidForLocalUser?.trim();
    if (existing != null &&
        existing.isNotEmpty &&
        existing != remoteIdentity.providerUserId) {
      return AccountLinkDecision.conflictingRemoteIdentity;
    }
    return AccountLinkDecision.eligibleForServerVerification;
  }
}
